-- =========================================================
-- Digital Ledger — PostgreSQL schema
-- Run this once against your database before first use.
-- =========================================================

CREATE TABLE IF NOT EXISTS admins (
    id              SERIAL PRIMARY KEY,
    username        VARCHAR(50)  NOT NULL UNIQUE,
    password_hash   TEXT         NOT NULL,         -- bcrypt hash
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS subscribers (
    id              SERIAL PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    phone_number    VARCHAR(20)  NOT NULL UNIQUE,  -- login ID
    pin_hash        TEXT         NOT NULL,         -- bcrypt hash of the 4-digit PIN
    total_meals     INTEGER      NOT NULL CHECK (total_meals >= 0),
    remaining_meals INTEGER      NOT NULL CHECK (remaining_meals >= 0),
    start_date      DATE         NOT NULL DEFAULT CURRENT_DATE,
    end_date        DATE         NOT NULL,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_subscribers_phone ON subscribers(phone_number);

-- Keep updated_at current automatically on every UPDATE
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_subscribers_updated_at ON subscribers;
CREATE TRIGGER trg_subscribers_updated_at
BEFORE UPDATE ON subscribers
FOR EACH ROW EXECUTE FUNCTION set_updated_at();
